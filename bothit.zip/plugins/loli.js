const fetch = require('node-fetch')

let handler = async (m, { conn }) => {
    let res = await fetch(global.API('xteam', '/randomimage/loli', {}, 'APIKEY'))
    if (!res.ok) throw await res.text()
    let img = await res.buffer()
    if (!img) throw img
    conn.sendFile(m.chat, img, '', '© insomnibot', m, 0, { thumbnail: await (await fetch(img)).buffer() })
}
handler.help = ['loli']
handler.tags = ['internet']
handler.command = /^(loli|pedo)$/i
handler.limit = true

module.exports = handler
