let handler = async m => m.reply(`
    *Latest Update & Bug Fixing*

  - Memperbaiki bug *Math*.
  - Merubah waktu pada *Math*.
  - Memperbaiki sistem curang pada *calc* saat sedang di fitur *Math*.
  - Merubah tampilan *Play*.
  - Menambahkan limit ukuran *YTMP4* (30MB to 50MB).
  - Mengubah *Daily* User (500 to 2000+)

  _Request fitur di #request teks_
  _Lapor bug/spam di #report bug_
`.trim())
handler.help = ['cekupdate']
handler.tags = ['main']
handler.command = /^(cekupdate|latest)$/i

module.exports = handler
