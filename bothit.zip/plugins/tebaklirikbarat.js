let fs = require('fs')
let timeout = 60000
let poin = 500
let handler = async (m, { conn, usedPrefix }) => {
    conn.guesslyric = conn.guesslyric ? conn.guesslyric : {}
    let id = m.chat
    if (id in conn.guesslyric) {
        conn.reply(m.chat, 'Masih ada soal belum terjawab di chat ini', conn.guesslyric[id][0])
        throw false
    }
    let guesslyric = JSON.parse(fs.readFileSync(`./src/tebaklirikbarat.json`))
    let json = guesslyric[Math.floor(Math.random() * guesslyric.length)]
    let caption = `
${json.soal}

Timeout *${(timeout / 1000).toFixed(2)} detik*
Ketik ${usedPrefix}guess untuk bantuan
Bonus: ${poin} XP
`.trim()
    conn.guesslyric[id] = [
        await conn.send2Button(m.chat, caption.trim(), '© insomnibot', 'BANTUAN', `${usedPrefix}guess`, 'NYERAH', 'nyerah'),
        json, poin,
        setTimeout(async () => {
            if (conn.guesslyric[id]) await conn.sendButton(m.chat, `Waktu habis!\nJawabannya adalah *${json.jawaban}*`, '', 'AGAIN!', `${usedPrefix}lyricguess`)
            delete conn.guesslyric[id]
        }, timeout)
    ]
}
handler.help = ['lyricguess']
handler.tags = ['game']
handler.command = /^lyricguess/i

module.exports = handler