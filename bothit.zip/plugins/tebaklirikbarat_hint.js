let handler = async (m, { conn }) => {
    conn.guesslyric = conn.guesslyric ? conn.guesslyric : {}
    let id = m.chat
    if (!(id in conn.guesslyric)) throw false
    let json = conn.guesslyric[id][1]
    let ans = json.jawaban.trim()
    let clue = ans.replace(/[AIUEOaiueo]/g, '_')
    conn.reply(m.chat, '```' + clue + '```\nBalas soalnya, bukan pesan ini', conn.guesslyric[id][0])
}
handler.command = /^guess$/i
handler.limit = true
module.exports = handler