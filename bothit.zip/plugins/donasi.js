let handler = async m => m.reply(`
╭─「 Donasi • Pulsa 」
│ • Telkomsel [081292229473]
│ • By.U [08515548965]
╰────

╭─「 Donasi • Non Pulsa 」
│ • Gopay [081292229473]
│ • Shopeepay [085891510705]
╰────

Barangsiapa yang suka berdonasi maka dia disayang admin 😱.~
`.trim())
handler.help = ['donasi']
handler.tags = ['info']
handler.command = /^dona(te|si)$/i

module.exports = handler
